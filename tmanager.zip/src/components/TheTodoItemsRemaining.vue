<template>
  <p>{{ remaining }} items left</p>
</template>

<script>
export default {
  name: "todo-remaining",
  computed: {
    remaining() {
      return this.$store.getters.remaining;
    },
  },
};
</script>
